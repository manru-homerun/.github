# 야단법석 실기기 화면 캡처

## 캡처 범위

- 날짜: 2026-10-18
- 기기: Samsung Galaxy S9 (SM-G960N)
- 설치 앱: 1.1 (versionCode 4)
- 형식: 원본 PNG, 1440 x 2960 px. 크롭·크기 조정·합성 없이 저장했습니다.
- 코드의 `feature/**/screen/*Screen.kt` 35개 중 현재 조건에서 접근 가능한 19개 화면을 캡처했습니다.
- 빈 목록, 검색 결과, 선택 상태, 스크롤 위치를 포함한 최종 PNG는 29장입니다.
- 모든 화면을 캡처한 것은 아닙니다. 접근하지 못한 16개 화면과 이유는 아래에 구분했습니다.

## 수행하지 않은 동작

- 로그아웃, 회원 탈퇴, 앱 데이터 초기화, 재설치
- 여행 AI 생성, 여행 저장·수정·삭제, 방문 인증
- 친구 요청 전송·수락·거절·취소·삭제
- 찜 상태 변경, 프로필·취향 저장, 알림 설정 토글 변경
- 이미지 저장·공유

여행 만들기는 경기·테마·기간을 미저장 상태로 선택해 관광지 담기/검색 화면까지만 열었습니다.
캡처 후 여행 만들기를 저장하지 않고 닫았으며, 휴대폰은 홈 화면으로 돌아갔습니다.
앱 소스와 설정 파일은 수정하지 않았습니다. 이 폴더는 기존 `/store-assets/` Git 제외 규칙 안에 있습니다.

## PNG 목록

| 파일 | 화면 / 상태 |
| --- | --- |
| [01_home/01_home.png](01_home/01_home.png) | 홈 |
| [01_home/02_home_leisure.png](01_home/02_home_leisure.png) | 홈 - 레저 필터 |
| [02_baseball/01_schedule_empty.png](02_baseball/01_schedule_empty.png) | 경기 일정 - 빈 목록 |
| [02_baseball/02_schedule_lg.png](02_baseball/02_schedule_lg.png) | 경기 일정 - LG |
| [03_travel_creation/01_game_empty.png](03_travel_creation/01_game_empty.png) | 여행 만들기 - 경기 선택(빈 목록) |
| [03_travel_creation/02_game_list.png](03_travel_creation/02_game_list.png) | 여행 만들기 - 경기 선택 |
| [03_travel_creation/03_companion_conditions.png](03_travel_creation/03_companion_conditions.png) | 여행 만들기 - 동행 조건 |
| [03_travel_creation/04_theme.png](03_travel_creation/04_theme.png) | 여행 만들기 - 테마 선택 |
| [03_travel_creation/05_companions.png](03_travel_creation/05_companions.png) | 여행 만들기 - 동행자 선택 |
| [03_travel_creation/06_dates_unselected.png](03_travel_creation/06_dates_unselected.png) | 여행 만들기 - 기간 선택 전 |
| [03_travel_creation/07_dates_selected.png](03_travel_creation/07_dates_selected.png) | 여행 만들기 - 기간 선택 후 |
| [03_travel_creation/08_spots_recommended.png](03_travel_creation/08_spots_recommended.png) | 여행 만들기 - 관광지 담기 |
| [03_travel_creation/09_spots_search.png](03_travel_creation/09_spots_search.png) | 여행 만들기 - 관광지 검색 결과 |
| [04_spots/01_detail_image_error.png](04_spots/01_detail_image_error.png) | 관광지 상세 - 이미지 오류 상태 |
| [04_spots/02_detail_top.png](04_spots/02_detail_top.png) | 관광지 상세 - 서울시립미술관 |
| [04_spots/03_detail_description_expanded.png](04_spots/03_detail_description_expanded.png) | 관광지 상세 - 소개 펼침 |
| [05_records/01_records_map.png](05_records/01_records_map.png) | 여행 기록 - 지도와 목록 |
| [05_records/02_detail_top.png](05_records/02_detail_top.png) | 완료 여행 상세 - 상단 |
| [05_records/03_detail_middle.png](05_records/03_detail_middle.png) | 완료 여행 상세 - 중간 |
| [05_records/04_detail_bottom.png](05_records/04_detail_bottom.png) | 완료 여행 상세 - 하단 |
| [06_mypage/01_my_page.png](06_mypage/01_my_page.png) | 마이페이지 |
| [06_mypage/02_profile_edit.png](06_mypage/02_profile_edit.png) | 프로필 수정(저장하지 않음) |
| [06_mypage/03_travel_preferences.png](06_mypage/03_travel_preferences.png) | 여행 취향 수정(저장하지 않음) |
| [06_mypage/04_dibs.png](06_mypage/04_dibs.png) | 찜한 관광지 |
| [07_friends/01_friend_list.png](07_friends/01_friend_list.png) | 친구 목록 |
| [07_friends/02_friend_requests.png](07_friends/02_friend_requests.png) | 친구 요청(받은 요청·보낸 요청 없음) |
| [07_friends/03_friend_search.png](07_friends/03_friend_search.png) | 친구 찾기 |
| [08_notifications/01_notification_list.png](08_notifications/01_notification_list.png) | 알림 목록 |
| [08_notifications/02_notification_settings.png](08_notifications/02_notification_settings.png) | 알림 설정(토글 변경하지 않음) |

## 미캡처 화면

| 화면 | 코드의 Screen | 사유 |
| --- | --- | --- |
| 로그인 | `LoginScreen` | 현재 로그인 상태이며, 로그아웃하지 않기로 하여 접근하지 않았습니다. |
| 가입 약관 동의 | `TermsAgreementScreen` | 신규 가입 흐름 진입이 필요합니다. 로그아웃·계정 초기화는 하지 않았습니다. |
| 가입 기본 정보 입력 | `BasicInfoScreen` | 신규 가입 흐름 진입이 필요합니다. |
| 가입 응원 팀 선택 | `TeamSelectionScreen` | 신규 가입 흐름 진입이 필요합니다. |
| 가입 여행 취향 입력 | `TravelProfileScreen` | 신규 가입 흐름 진입이 필요합니다. |
| AI 코스 생성 중 | `TravelCourseGeneratingScreen` | AI 생성 요청을 실행하지 않았습니다. |
| AI 코스 생성 결과 | `TravelCourseResultScreen` | AI 생성 요청을 실행하지 않아 결과가 없습니다. |
| 여행 일정 편집 | `TravelCourseEditScreen` | 생성된 코스나 편집 가능한 기존 여행이 필요합니다. 생성·저장 동작은 실행하지 않았습니다. |
| 일정 편집의 관광지 추가 | `TravelCourseSpotSelectionScreen` | 일정 편집 화면을 열 수 없어 접근하지 못했습니다. |
| 여행 저장 완료 | `TravelCourseSavedScreen` | 실제 저장을 실행해야 하므로 접근하지 않았습니다. |
| 진행 중 여행 상세 | `TravelDetailScreen` | 현재 홈에 진행 중인 여행이 없습니다. |
| 여행 이미지 공유 | `TravelShareScreen` | 진행 중 여행 상세에서 진입하는 화면이며, 현재 대상 여행이 없습니다. |
| 방문 인증 지도 | `TravelVerificationScreen` | 진행 중 여행 상세의 인증할 관광지가 필요합니다. |
| 방문 인증 완료 | `TravelVerificationCompletedScreen` | 실제 방문 인증을 실행해야 하므로 접근하지 않았습니다. |
| 스티커 획득 | `TravelStickerRewardScreen` | 인증 조건을 충족한 여행이 필요합니다. 실제 인증은 실행하지 않았습니다. |
| 스티커 사진 꾸미기 | `TravelStickerPhotoScreen` | 조회한 완료 여행 두 개 모두 스티커 미획득 상태입니다. |

## 참고

- 같은 화면의 여러 스크롤 위치는 별도 PNG로 저장했습니다. 긴 화면 전체를 하나의 긴 이미지로 합성하지 않았습니다.
- 관광지 상세의 이미지 오류 PNG는 캡처 당시 실제로 표시된 상태입니다. 원인을 확인하거나 수정한 작업은 아닙니다.
- 마이페이지 이용약관은 외부 브라우저로 열렸으나 캡처 명령이 빈 파일을 반환해 최종 PNG에서 제외했습니다. 개인정보 처리방침 본문은 캡처하지 않았습니다.
- 스플래시, 시스템 갤러리, 외부 브라우저, 개별 팝업, 모든 로딩·오류 변형은 위 35개 Screen 집계에 포함하지 않았습니다.
- 닉네임·친구 목록 등 실제 계정 정보가 포함되어 있으므로 외부 공유 전에 확인해 주세요.

